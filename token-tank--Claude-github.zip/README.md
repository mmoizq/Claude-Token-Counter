# Token Tank

An animated usage counter for Claude. It shows how much of your current session is left, when it refills, how fast you're burning through it, and tells you plainly when to keep going and when to take a break.

![Token Tank preview](preview.png)

One HTML file. No build step, no server, no tracking. Open `index.html` and it works.

## Features

- **Session left**: percentage and estimated tokens remaining
- **Refill countdown**: live `h:mm:ss` with flipping digits until your 5-hour window resets
- **Burn rate**: % and tokens per hour, based on your last 90 minutes
- **Runs dry in**: when you'll hit the limit at your current pace
- **Safe pace**: how much you can use per hour and still last until the refill
- **Weekly limit**: percent left, reset date and a daily allowance
- **Work / pause plan**: e.g. "work about 1h 20m more, then pause 40m"
- **Session chart**: usage so far, projection line and warning threshold

## Five themes

| Theme | Gauge |
| --- | --- |
| **Orbit** | Glowing ring with a comet tracing the refill clock, a drifting starfield and shooting stars |
| **Sands** | A gently swaying hourglass with glinting sand and grains bouncing off the pile |
| **Dash** | Analog fuel gauge with an ignition needle sweep, idle vibration and a low-fuel lamp |
| **Phosphor** | Green CRT terminal that types itself in on boot, with scanlines and signal glitches |
| **Tide** | A flask of water with waves, bubbles and light glinting on the surface |

## Animation details

- Tokens you log fly out of the button and land in the gauge with a shockwave
- Confetti when your session refills
- Circular reveal when switching themes
- Count-up numbers, value bumps and a bouncing status badge when things change
- Chart that draws itself in, with a pulsing "now" marker
- Pointer spotlight on cards and a 3D tilt on the gauge (desktop)
- Pulsing red glow when you're about to run out
- Drifting background aurora, light sweeps on progress bars, button ripples

All motion is turned off automatically for people who set "reduce motion" on their device.

## How to feed it numbers

Claude doesn't expose your limits to other websites, so the counter can't read them by itself. Use any of these:

1. **Sync from Claude (most accurate).** Open claude.ai → Settings → Usage and copy the session %, weekly % and reset times into the *Sync from Claude* tab.
2. **Log usage.** Tap quick buttons (+1k, +4k, +12k, +30k) or enter a custom token amount as you work.
3. **Import Claude Code logs (exact).** Claude Code writes token counts to `~/.claude/projects/<project>/*.jsonl` (Windows: `%USERPROFILE%\.claude\projects\`, some setups: `~/.config/claude/projects/`). Drop those files into the *Import* tab and it loads your active 5-hour block. Files are read locally in the browser.

Token figures are estimates based on the per-session budget in **Settings**. Anthropic doesn't publish exact limits; the presets (Pro 44k, Max 5x 220k, Max 20x 880k) are community estimates, so adjust them to match what you see.

All data is stored in your browser's `localStorage`. Nothing leaves your machine.

## Run it

- **In a browser:** double-click `index.html`.
- **On the web:** push this repo, then Settings → Pages → Deploy from branch → `main` / root. It goes live at `https://<username>.github.io/<repo>/`.

## Install it as an app

### Option 1: Install from the browser (quickest)

Once it's on GitHub Pages, open the link and install it. It gets its own window, icon and Start menu / Dock entry, and works offline.

- **Windows or Mac, Chrome or Edge:** click the install icon in the address bar (or menu → *Install Token Tank*).
- **Mac, Safari:** File → *Add to Dock*.

### Option 2: Download the desktop app (.exe / .dmg)

GitHub builds the installers for you, no Mac or Windows tools needed:

1. Push this repo to GitHub.
2. Open the **Actions** tab → **Build desktop apps** → **Run workflow**.
3. When it finishes (about 5 to 10 minutes), open the run and download:
   - `token-tank-Windows`: the installer (`Token-Tank-1.0.0-win-x64.exe`) and a portable `.exe` that runs without installing
   - `token-tank-macOS`: `Token-Tank-1.0.0-mac-universal.dmg` for both Intel and Apple Silicon Macs

To publish a proper download page, push a version tag instead and the installers are attached to a GitHub Release:

```bash
git tag v1.0.0
git push origin v1.0.0
```

**First launch warnings.** The apps are not code-signed, so the system warns you once:

- **Windows:** SmartScreen says "Windows protected your PC". Click *More info* → *Run anyway*.
- **Mac:** right-click the app → *Open* → *Open*. Or System Settings → Privacy & Security → *Open Anyway*.

Signing removes these warnings but needs paid certificates (an Apple Developer account for Mac, a code-signing certificate for Windows).

**Desktop extras** (View menu):

| Shortcut | Action |
| --- | --- |
| `Ctrl/Cmd + Shift + T` | Keep the window always on top |
| `Ctrl/Cmd + Shift + M` | Compact window, handy beside your Claude chat |
| `Ctrl/Cmd + Shift + F` | Back to full size |

### Build it yourself

Install [Node.js](https://nodejs.org) 20 or newer, then in this folder:

```bash
npm install
npm start          # run the app
npm run dist:win   # build the Windows installer (run on Windows)
npm run dist:mac   # build the Mac .dmg (run on a Mac)
```

Installers land in the `dist/` folder.

## Tech

Plain HTML, CSS and JavaScript with Canvas 2D. Fonts from Google Fonts (falls back to system fonts offline). The desktop app wraps the same `index.html` in [Electron](https://www.electronjs.org).

## License

MIT. See [LICENSE](LICENSE).

Not affiliated with Anthropic. Claude is a trademark of Anthropic.
